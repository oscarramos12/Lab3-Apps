package com.example.lab3

data class info(val tipo: String){
    var title = ""
    var subtitle = ""
    var desc = ""

    /*if(tipo == "virus"){

        title = "COVID-19"
        subtitle = "Virus"
        desc = "COVID-19nota 2\u200B (acrónimo del inglés coronavirus disease 2019),4\u200B también conocida como enfermedad por coronavirus3\u200B o, incorrectamente, como neumonía por coronavirus,nota 1\u200B es una enfermedad infecciosa causada por el virus SARS-CoV-2.9\u200B10\u200B Se detectó por primera vez en la ciudad china de Wuhan (provincia de Hubei), en diciembre de 2019.11\u200B12\u200B Habiendo llegado a más de 100 territorios, el 11 de marzo de 2020 la Organización Mundial de la Salud la declaró pandemia.13\u200B\n" +
                "\n" +
                "Produce síntomas similares a los de la gripe, entre los que se incluyen fiebre, tos seca,14\u200B disnea, mialgia y fatiga.15\u200B16\u200B En casos graves se caracteriza por producir neumonía, síndrome de dificultad respiratoria aguda,17\u200B sepsis18\u200B y choque séptico que conduce a alrededor del 3 % de los infectados a la muerte.[cita requerida] No existe tratamiento específico; las medidas terapéuticas principales consisten en aliviar los síntomas y mantener las funciones vitales.15\u200B\n" +
                "\n" +
                "La transmisión del SARS-CoV-2 se produce mediante pequeñas gotas —microgotas de Flügge19\u200B— que se emiten al hablar, estornudar, toser o espirar, que al ser despedidas por un portador (que puede no tener síntomas de la enfermedad o estar incubándola)20\u200B pasan directamente a otra persona mediante la inhalación, o quedan sobre los objetos y superficies que rodean al emisor, y luego, a través de las manos, que lo recogen del ambiente contaminado, toman contacto con las membranas mucosas orales, nasales y oculares, al tocarse la boca, la nariz o los ojos.21\u200B22\u200B Esta última es la principal vía de propagación, ya que el virus puede permanecer viable hasta por días en los fómites (cualquier objeto carente de vida, o sustancia, que si se contamina con algún patógeno es capaz de transferirlo de un individuo a otro).20\u200B\n" +
                "\n" +
                "Los síntomas aparecen entre dos y catorce días, con un promedio de cinco días, después de la exposición al virus.23\u200B24\u200B25\u200B26\u200B Existe evidencia limitada que sugiere que el virus podría transmitirse uno o dos días antes de que se tengan síntomas, ya que la viremia alcanza un pico al final del período de incubación.27\u200B28\u200B El contagio se puede prevenir con el lavado de manos frecuente, o en su defecto la desinfección de las mismas con alcohol en gel, cubriendo la boca al toser o estornudar, ya sea con la sangradura (parte hundida del brazo opuesta al codo) o con un pañuelo y evitando el contacto cercano con otras personas,21\u200B entre otras medidas profilácticas, como el uso de mascarillas. La OMS desaconsejaba en marzo la utilización de máscara quirúrgica por la población sana, 29\u200B30\u200B en abril la OMS consideró que era una medida aceptable en algunos países. 31\u200B No obstante, ciertos expertos recomiendan el uso de máscaras quirúrgicas basados en estudios sobre la Influenza H1N1, donde muestran que podrían ayudar a reducir la exposición al virus.32\u200B Los CDC recomiendan el uso de mascarillas de tela, no médicas.33\u200B "

    }
    else if(tipo == "sintomas"){
        title = "COVID-19"
        subtitle = "Sintomas"
        desc = "Síntomas comunes:\n" +
                "fiebre\n" +
                "cansancio\n" +
                "tos seca\n" +
                "Algunas personas también pueden experimentar:\n" +
                "dolores y molestias\n" +
                "congestión nasal\n" +
                "abundante secreción nasal\n" +
                "dolor de garganta\n" +
                "diarrea"
    }
    else if(tipo == "indi"){
        title = "COVID-19"
        subtitle = "Indicaciones"
        desc = "1\n" +
                "QUÉDATEen casa lo máximo posible\n" +
                "2\n" +
                "MANTÉNel distanciamiento social\n" +
                "3\n" +
                "LÁVATElas manos con frecuencia\n" +
                "4\n" +
                "TOSEcubriéndote con el codo\n" +
                "5\n" +
                "LLAMAsi tienes síntomas"
    }*/

}
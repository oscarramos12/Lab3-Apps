package com.example.lab3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.example.lab3.databinding.ActivityMainBinding
import androidx.databinding.DataBindingUtil

class MainActivity : AppCompatActivity() {

    private lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.imageButton.setOnClickListener{
            func(it)
        }
        binding.button.setOnClickListener{
            val i = Intent(this, Main2Activity::class.java)
            startActivity(i)
            i.putExtra("titulo", "Covid-19")
            i.putExtra("sub", "Virus")
            i.putExtra("desc", "poop")
            finish()
        }
        binding.button2.setOnClickListener{
            val i = Intent(this, Main2Activity::class.java)
            startActivity(i)
            finish()
        }
        binding.button3.setOnClickListener{
            val i = Intent(this, Main2Activity::class.java)
            startActivity(i)
            finish()
        }

    }

    private fun func(view: View){
        var nombre = binding.editText
        var edad = binding.editText3
        var tnombre = binding.textView2
        var tedad = binding.textView
        var texto = binding.textView4


        if(edad.text.toString().toInt() <= 40 && texto.visibility == View.INVISIBLE){
            texto.text = nombre.text.toString() + " te encuentras fuera de peligro"
            texto.visibility = View.VISIBLE
            tnombre.visibility = View.INVISIBLE
            tedad.visibility = View.INVISIBLE
            nombre.visibility = View.INVISIBLE
            edad.visibility = View.INVISIBLE
        }
        else if(texto.visibility == View.VISIBLE){
            texto.visibility = View.INVISIBLE
            tnombre.visibility = View.VISIBLE
            tedad.visibility = View.VISIBLE
            nombre.visibility = View.VISIBLE
            edad.visibility = View.VISIBLE
        }
        else if(edad.text.toString().toInt() > 40 && texto.visibility == View.INVISIBLE){
            texto.text = nombre.text.toString() + " te encuentras en peligro"
            texto.visibility = View.VISIBLE
            tnombre.visibility = View.INVISIBLE
            tedad.visibility = View.INVISIBLE
            nombre.visibility = View.INVISIBLE
            edad.visibility = View.INVISIBLE
        }

    }

}


